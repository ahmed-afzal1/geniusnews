(function($) {
    "use strict";

    


})(jQuery);