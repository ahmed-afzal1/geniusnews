(function($) {
    "use strict";

    var title = "<?php echo $title; ?>";
    var image = "<?php echo $image; ?>";
    var audio = "<?php echo $audio; ?>";

})(jQuery);