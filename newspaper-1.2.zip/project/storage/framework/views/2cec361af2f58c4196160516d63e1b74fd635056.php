

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('contents'); ?>

  <!-- Breadcrumb Area Start -->
  <div class="breadcrumb-area">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="pagetitle">
            <?php echo e(__("404")); ?>

          </h1>

          <ul class="pages">
                
              <li>
                <a href="<?php echo e(route('frontend.index')); ?>">
                  <?php echo e(__("Home")); ?>

                </a>
              </li>
              <li>
                <a href="javascript:;">
                  <?php echo e(__("404")); ?>

                </a>
              </li>

          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Breadcrumb Area End -->


<section class="fourzerofour">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="content">
            <img src="<?php echo e(asset('assets/images/'.$gs->error_photo)); ?>" alt="">

              <p><?php echo $gs->error_title; ?></p>
              <p><?php echo $gs->error_text; ?></p>
            <a class="mybtn1 pt-3" href="<?php echo e(route('frontend.index')); ?>"><?php echo e(__("Back To Home Page")); ?></a>
          </div>
        </div>
      </div>
    </div>
  </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newspaper\project\resources\views/errors/404.blade.php ENDPATH**/ ?>