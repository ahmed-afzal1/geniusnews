<?php echo $__env->yieldContent('styles'); ?>

<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('assets/admin/js/vendors/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/jqueryui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/vendors/vue.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-colorpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/plugin.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/tag-it.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/load.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/newspaper.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>

<?php /**PATH F:\xampp\htdocs\newspaper\project\resources\views/layouts/load.blade.php ENDPATH**/ ?>