

<?php $__env->startSection('content'); ?>
<div class="content-area">
    <div class="row row-cards-one">
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="mycard bg1">
                <div class="left">
                    <h5 class="title"><?php echo e(__('Post')); ?> </h5>
                    <?php
                        $user = Auth::guard('admin')->user()->role;
                    ?>
                    <?php if($user->name != 'admin' && $user->name != 'moderator'): ?>
                        <span class="number"><?php echo e($author_post); ?></span>
                    <?php else: ?> 
                        <span class="number"><?php echo e($total_post); ?></span>
                    <?php endif; ?>
                    <a href="<?php echo e(route('post.index')); ?>" class="link"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="right d-flex align-self-center">
                    <div class="icon">
                        <i class="fab fa-blogger-b"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="mycard bg2">
                <div class="left">
                    <h5 class="title"><?php echo e(__('Pending Post')); ?></h5>
                    <?php if($user->name != 'admin' && $user->name != 'moderator'): ?>
                        <span class="number"><?php echo e($author_pending); ?></span>
                    <?php else: ?> 
                        <span class="number"><?php echo e($pending_posts); ?></span>
                    <?php endif; ?>
                    <a href="<?php echo e(route('pending.index')); ?>" class="link"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="right d-flex align-self-center">
                    <div class="icon">
                        <i class="fas fa-hourglass"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="mycard bg3">
                <div class="left">
                    <h5 class="title"><?php echo e(__('Draft')); ?></h5>
                    <span class="number"><?php echo e($drafts); ?></span>
                    <a href="<?php echo e(route('draft.index')); ?>" class="link"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="right d-flex align-self-center">
                    <div class="icon">
                        <i class="fas fa-pen-square"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="mycard bg4">
                <div class="left">
                    <h5 class="title"><?php echo e(__('Schedule Post')); ?></h5>
                    <span class="number"><?php echo e($schedules); ?></span>
                    <a href="<?php echo e(route('schedule.index')); ?>" class="link"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="right d-flex align-self-center">
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="mycard bg5">
                <div class="left">
                    <h5 class="title"><?php echo e(__('Rss Feeds')); ?></h5>
                    <span class="number"><?php echo e($rss); ?></span>
                    <a href="<?php echo e(route('rss.index')); ?>" class="link"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="right d-flex align-self-center">
                    <div class="icon">
                        <i class="fas fa-rss"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-6 col-xl-4">
            <div class="mycard bg6">
                <div class="left">
                    <h5 class="title"><?php echo e(__('Polls')); ?></h5>
                    <span class="number"><?php echo e($polls); ?></span>
                    <a href="<?php echo e(route('addPolls.index')); ?>" class="link"><?php echo e(__('View All')); ?></a>
                </div>
                <div class="right d-flex align-self-center">
                    <div class="icon">
                        <i class="fas fa-poll"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newspaper\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>