

<?php $__env->startSection('contents'); ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="pages">
                    <li>
                        <a href="<?php echo e(route('frontend.index')); ?>">
                            <?php echo e(__('Home')); ?>

                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.forgot')); ?>">
                            <?php echo e(__('Forgot password')); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>


<section class="login-signup forgot-password">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="login-area">
                    <div class="header-area forgot-passwor-area">
                        <h4 class="title"><?php echo e(__('FORGOT PASSWORD')); ?> </h4>
                        <p class="text"><?php echo e(__('Please Write your Email')); ?> </p>
                    </div>
                    <div class="login-form">
                        <?php echo $__env->make('includes.validation.form_validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form id="forgotform" action="<?php echo e(route('front.forgot.submit')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-input">
                                <input type="email" name="email" class="User Name" placeholder="<?php echo e(__('Email Address')); ?>"
                                    required="">
                                <i class="icofont-user-alt-5"></i>
                            </div>
                            <div class="to-login-page">
                                <a href="<?php echo e(route('front.LogReg')); ?>">
                                    <?php echo e(__('Login Now')); ?>

                                </a>
                            </div>
                            <input class="authdata" type="hidden" value="<?php echo e(__('Checking...')); ?>">
                            <button type="submit" class="submit-btn"><?php echo e(__('submit')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\mamp\htdocs\newspaper-1.1\project\resources\views/frontend/forgot.blade.php ENDPATH**/ ?>