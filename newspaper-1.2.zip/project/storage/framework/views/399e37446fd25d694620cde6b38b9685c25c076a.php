

<?php $__env->startSection('content'); ?>

<div class="content-area">
    <div class="mr-breadcrumb">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="heading"><?php echo e(__('Add Pages')); ?></h4>
                <ul class="links">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.page.create')); ?>"><?php echo e(__('Pages')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="add-product-content">
        <?php echo $__env->make('includes.admin.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="product-description">
                    <div class="body-area">
                    <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                     <form id="geniusformdata" action="<?php echo e(route('admin.page.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Language')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <select name="language_id" id="language_id">
                                    <option value=""><?php echo e(__('Please Select a Language')); ?></option>
                                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($language->id); ?>"><?php echo e($language->language); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Title')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <input type="text" name="title" id="title" class="input-field" placeholder="<?php echo e(__('Title')); ?>" autocomplete="off">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Slug')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <input type="text" name="slug" id="slug" class="input-field" placeholder="<?php echo e(__('Slug')); ?>">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Placement')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <select name="placement" id="placement">
                                    <option value=""><?php echo e(__('Please Select a Placement')); ?></option>
                                    <option value="footer"><?php echo e(__('Footer')); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Content')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-12">
                               <textarea name="description" id="description" cols="30" rows="10" class="nic-edit"></textarea>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Status')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="custom-control custom-radio d-inline-block mr-4">
                                    <input class="custom-control-input" type="radio" name="status" id="enable" value="1"> 
                                    <label class="custom-control-label" for="enable"><?php echo e(__('Enable')); ?></label>
                                </div>
                                <div class="custom-control custom-radio d-inline-block">
                                    <input class="custom-control-input" type="radio" name="status" id="disable" value="0" checked> 
                                    <label class="custom-control-label" for="disable"><?php echo e(__('Disable')); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Show Website Right Column')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="custom-control custom-radio d-inline-block mr-4">
                                    <input class="custom-control-input" type="radio" name="wbsite_right_column" id="yes" value="1"> 
                                    <label class="custom-control-label" for="yes"><?php echo e(__('Yes')); ?></label>
                                </div>
                                <div class="custom-control custom-radio  d-inline-block">
                                    <input class="custom-control-input" type="radio" name="wbsite_right_column" id="no" value="0" checked> 
                                    <label class="custom-control-label" for="no"><?php echo e(__('No')); ?></label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">

                                </div>
                            </div>
                            <div class="col-lg-12">
                                <button class="addProductSubmit-btn"
                                    type="submit"><?php echo e(__('Add Page')); ?></button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/admin/js/page.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newspaper\project\resources\views/admin/page/create.blade.php ENDPATH**/ ?>