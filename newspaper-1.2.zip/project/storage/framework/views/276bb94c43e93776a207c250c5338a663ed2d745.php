<?php if(Auth::guard('admin')->user()->sectionCheck('menu_builder')): ?>
<li>
    <a href="<?php echo e(route('admin.menu.builder')); ?>" >
        <i class="fas fa-bars"></i><?php echo e(__('Menu Builder')); ?>

    </a>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('pages')): ?>   
<li>
    <a href="#page" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-window-restore"></i><?php echo e(__('Pages')); ?>

    </a>
    <ul class="collapse list-unstyled" id="page" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.page.create')); ?>"><i class="fas fa-angle-double-right"></i><span><?php echo e(__('Add Page')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.page.index')); ?>"><i class="fas fa-angle-double-right"></i><span><?php echo e(__('Pages')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('categories')): ?>   
<li>
    <a href="#menu2" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-folder-open"></i><?php echo e(__('Categories')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu2" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('categories.index')); ?>"><i class="fas fa-angle-double-right"></i><span><?php echo e(__('Categories')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('subcategories.index')); ?>"><i class="fas fa-angle-double-right"></i><span><?php echo e(__('SubCategories')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<li>
    <a href="<?php echo e(route('admin.post.format')); ?>" >
        <i class="fa fa-file"></i><?php echo e(__('Add Post')); ?>

    </a>
</li>


<?php if(Auth::guard('admin')->user()->sectionCheck('add_gallery')): ?>   
<li>
    <a href="#gallery" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-image"></i><?php echo e(__('Add Gallery')); ?>

    </a>
    <ul class="collapse list-unstyled" id="gallery" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('image.gallery.index')); ?>"><span><?php echo e(__('Show Image Gallery')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('image.gallery.create')); ?>"><span><?php echo e(__('Make Image Gallery')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('image.album.index')); ?>"><span><?php echo e(__('Make Album')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('image.category.index')); ?>"><span><?php echo e(__('Make Categories')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('posts')): ?>   
<li>
    <a href="#menu4" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-bars"></i><?php echo e(__('Posts')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu4" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('post.index')); ?>"><span><?php echo e(__('Posts')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('slider.index')); ?>"><span><?php echo e(__('Slider Posts')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('feature.index')); ?>"><span><?php echo e(__('Featured Posts')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('breaking.index')); ?>"><span><?php echo e(__('Breaking News')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('pending.index')); ?>"><span><?php echo e(__('Pending Posts')); ?></span></a>
        </li>

    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('schedule_post')): ?>    
<li>
    <a href="<?php echo e(route('schedule.index')); ?>"><span><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e(__('Schedule Post')); ?></span></a>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('drafts')): ?>    
<li>
    <a href="<?php echo e(route('draft.index')); ?>"><span><i class="fab fa-firstdraft"></i><?php echo e(__('Drafts')); ?></span></a>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('rss_feeds')): ?>   
<li>
    <a href="#rss" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-rss"></i><?php echo e(__('Rss Feeds')); ?>

    </a>
    <ul class="collapse list-unstyled" id="rss" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('rss.create')); ?>"><span><?php echo e(__('Import Rss Feeds')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('rss.index')); ?>"><span><?php echo e(__('Rss Feeds')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('polls')): ?>    
<li>
    <a href="#poll" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-list"></i><?php echo e(__('Polls')); ?>

    </a>
    <ul class="collapse list-unstyled" id="poll" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('addPolls.create')); ?>"><span><?php echo e(__('Add Polls')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('addPolls.index')); ?>"><span><?php echo e(__('Polls')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('widgets')): ?>   
<li>
    <a href="#widget" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-tachometer-alt"></i><?php echo e(__('Widgets')); ?>

    </a>
    <ul class="collapse list-unstyled" id="widget" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('widget.create')); ?>"><span><?php echo e(__('Add Widgets')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('widget.index')); ?>"><span><?php echo e(__('Widgets')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('widget.settings')); ?>"><span><?php echo e(__('Widget Settings')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('create_ads')): ?>    
<li>
    <a href="#menu8" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-dollar-sign"></i><?php echo e(__('Adverisment Spaces')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu8" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('ads.create')); ?>"><span><?php echo e(__('Create Ads')); ?></span></a>
        </li>

        <li>
            <a href="<?php echo e(route('ads.index')); ?>"><span><?php echo e(__('All Ads')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('newsLetter')): ?>   
<li>
    <a href="#menu9" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-envelope"></i><?php echo e(__('NewsLetter')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu9" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.subscriber.email')); ?>"><span><?php echo e(__('Send Email')); ?></span></a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.subscriber.index')); ?>"><span><?php echo e(__('All Subscribers')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>

<?php if(Auth::guard('admin')->user()->sectionCheck('languages')): ?>    
<li>
    <a href="#menu10" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-language"></i><?php echo e(__('Languages')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu10" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.language.index')); ?>"><span><?php echo e(__('Language')); ?></span></a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.admin_language.index')); ?>"><span><?php echo e(__('Admin Language')); ?></span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('general_settings')): ?>    
<li>
    <a href="#general" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-cogs"></i>General Settings
    </a>
    <ul class="collapse list-unstyled" id="general" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.generalsettings.logo')); ?>"><span>Logo</span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.languagelogo.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Language Base Logo')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.favicon')); ?>"><span>Favicon</span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.loader')); ?>"><span>loader</span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.websiteContent')); ?>"><span>Website Contents</span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.popularTags')); ?>"><span>Popular Tags</span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.footer')); ?>"><span>Footer</span></a>
        </li>
        
        <li>
            <a href="<?php echo e(route('admin.generalsettings.errorPage')); ?>"><span>Error Page</span></a>
        </li>

    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('social_settings')): ?>    
<li>
    <a href="#socials" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-paper-plane"></i><?php echo e(__('Social Settings')); ?>

    </a>
    <ul class="collapse list-unstyled" id="socials" data-parent="#accordion">
            <li><a href="<?php echo e(route('social.link.index')); ?>"><span><?php echo e(__('Social Links')); ?></span></a></li>
            <li><a href="<?php echo e(route('social.settings.google')); ?>"><span><?php echo e(__('Google Login')); ?></span></a></li>
            <li><a href="<?php echo e(route('social.settings.facebook')); ?>"><span><?php echo e(__('Facebook Login')); ?></span></a></li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('emails_settings')): ?>    
<li>
    <a href="#emails" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-at"></i>Email Settings
    </a>
    <ul class="collapse list-unstyled" id="emails" data-parent="#accordion">
        <li><a href="<?php echo e(route('admin.email.config')); ?>"><span>Email Configurations</span></a></li>    
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('seo_tools')): ?>   
<li>
    <a href="#seoTools" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-wrench"></i>SEO Tools
    </a>
    <ul class="collapse list-unstyled" id="seoTools" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('seo.google.analytics')); ?>"><span>Google Analytics</span></a>
        </li
        >
        <li>
            <a href="<?php echo e(route('seo.meta.keywords')); ?>"><span>Website Meta Keywords</span></a>
        </li>
    </ul>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('site_map')): ?>  
<li>
    <a href="<?php echo e(route('admin.sitemap.all')); ?>" class=" wave-effect"><i class="fas fa-sitemap"></i><?php echo e(__('Site Map')); ?></a>
</li>
<?php endif; ?>

<?php if(Auth::guard('admin')->user()->sectionCheck('font_option')): ?>    
<li>
    <a href="<?php echo e(route('fonts.index')); ?>" class=" wave-effect"><i class="fa fa-font"></i><?php echo e(__('Font Option')); ?></a>
</li>
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('role_management')): ?>
<li>
    <a href="<?php echo e(route('admin.role.index')); ?>" class=" wave-effect"><i class="fas fa-user-tag"></i><?php echo e(__('Role Management')); ?></a>
</li>  
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('user_management')): ?>
<li>
    <a href="<?php echo e(route('admin.staff.index')); ?>" class=" wave-effect"><i class="fas fa-user-secret"></i><?php echo e(__('User Management')); ?></a>
</li>   
<?php endif; ?>


<?php if(Auth::guard('admin')->user()->sectionCheck('cache_management')): ?>
<li>
    <a href="<?php echo e(route('admin.cache.clear')); ?>" class=" wave-effect"><i class="fa fa-database"></i><?php echo e(__('Clear Cache')); ?></a>
</li>    
<?php endif; ?><?php /**PATH C:\wamp\htdocs\newspaper-1.1\project\resources\views/partial/admin-role/normal.blade.php ENDPATH**/ ?>