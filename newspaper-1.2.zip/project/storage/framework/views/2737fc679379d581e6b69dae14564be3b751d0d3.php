

<?php $__env->startPush('css'); ?>
    <style>
        .js-cookie-consent{
                position: fixed;
                bottom: 0px;
                padding: 14px;
                color  : #fff;
                text-align: center;
                width: 100%;
                z-index: 10000000000;
                background-color: #8e44ad;
                border-color: #8e44ad;
            }
    </style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('contents'); ?>

<!-- Top Header Area Start -->
<section class="top-header">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="content">
                    <div class="left-content">
                        <div class="heading">
                            <span><?php echo e(__('Trending Now!')); ?> </span>
                        </div>
                        <div class='marquee'>
                            <marquee onMouseOver="this.stop()" onMouseOut="this.start()" scrollamount="5">
                                <?php echo $is_breaking; ?></marquee>
                        </div>
                    </div>
                    <div class="right-content">
                        <span class="date-now"><?php echo e(\Carbon\Carbon::now()->toFormattedDateString()); ?><span class="time-now"></span></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Top Header Area End -->

<!-- Hero Area Start -->
<section class="hero-area">
    <div class="container">
        <div class="row py">
            <div class="col-lg-6 r-p">
                <div class="intro-carousel">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.details',[$slider->id,$slider->slug])); ?>" class="single-news big">
                            <div class="content-wrapper">
                                <?php if($slider->image_big || $slider->rss_image): ?>
                                    <div class="tag" style="background:<?php echo e($slider->category->color); ?>">
                                        <?php echo e($slider->category->title); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if($slider->image_big || $slider->rss_image): ?>
                                    <?php if($slider->image_big): ?>
                                        <img src="<?php echo e(asset('assets/images/post/'.$slider->image_big)); ?>"  alt="">
                                    <?php endif; ?>

                                    <?php if($slider->rss_image): ?>
                                        <img src="<?php echo e($slider->rss_image); ?>" alt="">
                                    <?php endif; ?>

                                    <?php if($slider->post_type == 'audio'): ?>
                                        <span  class="vid-aud">
                                            <i class="fas fa-volume-up"></i>
                                        </span>
                                    <?php endif; ?>
                                    <?php if($slider->post_type == 'video'): ?>
                                        <span  class="vid-aud">
                                            <i class="fas fa-video"></i>
                                        </span> 
                                    <?php endif; ?>
                                <?php else: ?> 
                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                <?php endif; ?>
                                <div class="inner-content">
                                    <span>
                                        <h4 class="title">
                                            <?php echo e(strlen($slider->title)>40 ? mb_substr($slider->title,0,40,"utf-8") : $slider->title); ?>

                                        </h4>
                                    </span>
                                    <ul class="post-meta">
                                        <li>
                                            <span>
                                                <?php echo e($slider->createdAt()); ?>

                                            </span>
                                        </li>
                                        <li>
                                            <span>|</span>
                                        </li>
                                        <li>
                                            <span>
                                                <?php echo e($slider->admin->name); ?>

                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-lg-3 r-p mycol">
                <?php $__currentLoopData = $slider_rights_firsts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider_rights_first): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('frontend.details',[$slider_rights_first->id,$slider_rights_first->slug])); ?>" class="single-news animation">
                        <div class="content-wrapper">
                            <?php if($slider_rights_first->image_big || $slider_rights_first->rss_image): ?>
                                <div class="tag" style="background:<?php echo e($slider_rights_first->category->color); ?>">
                                    <?php echo e($slider_rights_first->category->title); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($slider_rights_first->image_big || $slider_rights_first->rss_image): ?>
                                <?php if($slider_rights_first->image_big): ?>
                                    <img data-src="<?php echo e(asset('assets/images/post/'.$slider_rights_first->image_big)); ?>" alt="" class="lazy">
                                <?php endif; ?>
                                <?php if($slider_rights_first->rss_image): ?>
                                    <img data-src="<?php echo e($slider_rights_first->rss_image); ?>" alt="" class="lazy">
                                <?php endif; ?>
                                <?php if($slider_rights_first->post_type == 'audio'): ?>
                                    <span  class="vid-aud">
                                        <i class="fas fa-volume-up"></i>
                                    </span>
                                <?php endif; ?>
                                <?php if($slider_rights_first->post_type == 'video'): ?>
                                    <span  class="vid-aud">
                                        <i class="fas fa-video"></i>
                                    </span> 
                                <?php endif; ?>
                            <?php else: ?> 
                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                            <?php endif; ?>
                            <div class="inner-content">
                                <span>
                                    <h4 class="title">
                                        <?php echo e(strlen($slider_rights_first->title)>40 ? mb_substr($slider_rights_first->title,0,40,"utf-8") : $slider_rights_first->title); ?>

                                    </h4>
                                </span>
                                <ul class="post-meta">
                                    <li>
                                        <span>
                                            <?php echo e($slider_rights_first->createdAt()); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span>|</span>
                                    </li>
                                    <li>
                                        <span>
                                            <?php echo e($slider_rights_first->admin->name); ?>

                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-3 r-p mycol">
                <?php $__currentLoopData = $slider_rights_seconds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider_rights_second): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('frontend.details',[$slider_rights_second->id,$slider_rights_second->slug])); ?>" class="single-news animation">
                        <div class="content-wrapper">
                            <?php if($slider_rights_second->image_big || $slider_rights_second->rss_image): ?>
                                <div class="tag" style="background:<?php echo e($slider_rights_second->category->color); ?>">
                                    <?php echo e($slider_rights_second->category->title); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($slider_rights_second->image_big || $slider_rights_second->rss_image): ?>
                                <?php if($slider_rights_second->post_type == 'audio'): ?>
                                <span  class="vid-aud">
                                    <i class="fas fa-volume-up"></i>
                                </span>
                                <?php endif; ?>
                                <?php if($slider_rights_second->post_type == 'video'): ?>
                                    <span  class="vid-aud">
                                        <i class="fas fa-video"></i>
                                    </span> 
                                <?php endif; ?>
                                <?php if($slider_rights_second->image_big): ?>
                                    <img data-src="<?php echo e(asset('assets/images/post/'.$slider_rights_second->image_big)); ?>" alt="" class="lazy">
                                <?php endif; ?>
                                <?php if($slider_rights_second->rss_image): ?>
                                    <img data-src="<?php echo e($slider_rights_second->rss_image); ?>" alt="" class="lazy">
                                <?php endif; ?>
                            <?php else: ?> 
                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                            <?php endif; ?>
                            <div class="inner-content">
                                <span>
                                    <h4 class="title">
                                        <?php echo e(strlen($slider_rights_second->title)>40 ? mb_substr($slider_rights_second->title,0,40,"utf-8") : $slider_rights_first->title); ?>

                                    </h4>
                                </span>
                                <ul class="post-meta">
                                    <li>
                                        <span>
                                            <?php echo e($slider_rights_second->createdAt()); ?>

                                        </span>
                                    </li>
                                    <li>
                                        <span>|</span>
                                    </li>
                                    <li>
                                        <span>
                                            <?php echo e($slider_rights_second->admin->name); ?>

                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- Hero Area End -->

<!-- Home Front Area Start -->
<section class="home-front-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <?php $__currentLoopData = $home_page_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home_page_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($home_page_post->child)>0): ?>
                        <?php if(count($home_page_post->posts)>0): ?>
                            <!-- News Tabs start -->
                            <div class="main-content tab-view">
                                <div class="row">
                                    <div class="col-lg-12 mycol">
                                        <div class="header-area">
                                            <h3 class="title">
                                                <?php echo e($home_page_post->title); ?>

                                            </h3>
                                            <ul class="nav" role="tablist">
                                                <?php $__currentLoopData = $home_page_post->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item">
                                                    <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="pills-home-tab" data-toggle="pill" href="#pills-<?php echo e($child->slug); ?>" role="tab" aria-controls="pills-<?php echo e($child->slug); ?>" aria-selected="true"><?php echo e($child->title); ?></a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="tab-content" id="pills-tabContent">
                                            <?php $__currentLoopData = $home_page_post->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="pills-<?php echo e($child->slug); ?>" role="tabpanel" aria-labelledby="pills-<?php echo e($child->slug); ?>-tab">
                                                    <div class="row">
                                                        <div class="col-md-6 mycol">
                                                            <?php if($child->subcategoryPosts()->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->count()>0): ?>
                                                            <?php $__currentLoopData = $child->subcategoryPosts()->orderBy('id','desc')->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->take(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="single-news landScape-normal">
                                                                    <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                                        <div class="content-wrapper">
                                                                            <div class="img">
                                                                                <?php if($post->image_big || $post->rss_image): ?>
                                                                                    <div class="tag" style="background:<?php echo e($home_page_post->color); ?>">
                                                                                        <?php echo e($post->category->title); ?>

                                                                                    </div>
                                                                                <?php endif; ?>
                                                                                <?php if($post->image_big || $post->rss_image): ?>
                                                                                    <?php if($post->image_big): ?>
                                                                                        <img data-src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="" class="lazy">
                                                                                    <?php endif; ?>
                                                                                    <?php if($post->rss_image): ?>
                                                                                        <img data-src="<?php echo e($post->rss_image); ?>" alt="" class="lazy">
                                                                                    <?php endif; ?>
                                                                                    <?php if($post->post_type == 'audio'): ?>
                                                                                        <span  class="vid-aud">
                                                                                            <i class="fas fa-volume-up"></i>
                                                                                        </span>
                                                                                    <?php endif; ?>
                                                                                    <?php if($post->post_type == 'video'): ?>
                                                                                        <span  class="vid-aud">
                                                                                            <i class="fas fa-video"></i>
                                                                                        </span> 
                                                                                    <?php endif; ?>
                                                                                <?php else: ?> 
                                                                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                                                <?php endif; ?>
                                                                            </div>
                                                                            <div class="inner-content">
                                                                                <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                                                    <h4 class="title">
                                                                                        <?php echo e(strlen($post->title)>170 ? mb_substr($post->title,0,170,'utf-8').'...' : $post->title); ?>

                                                                                    </h4>
                                                                                    <p class="text">
                                                                                        <?php echo (strlen(convertUtf8(strip_tags($post->description))) > 400) ? convertUtf8(substr(strip_tags($post->description), 0, 400)) . '...' : convertUtf8(strip_tags($post->description)); ?>

                                                                                    </p>
                                                                                    <ul class="post-meta">
                                                                                        <li>
                                                                                        <a href="<?php echo e(route('frontend.postByDate').'?date='.$post->created_at->format('Y-m-d')); ?>">
                                                                                                <?php echo e($post->createdAt()); ?>

                                                                                            </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <span>|</span>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="<?php echo e(route('front.authorProfile',$post->admin->name)); ?>">
                                                                                                <?php echo e($post->admin->name); ?>

                                                                                            </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="col-md-6 mycol">
                                                            <?php if($child->subcategoryPosts()->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->count()>0): ?>
                                                            <?php $__currentLoopData = $child->subcategoryPosts()->orderBy('id','desc')->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->skip(1)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                                    <div class="single-box landScape-small-with-meta">
                                                                        <div class="img">
                                                                            <?php if($post->image_big || $post->rss_image): ?>
                                                                                <?php if($post->image_big): ?>
                                                                                    <img data-src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="" class="lazy">
                                                                                <?php endif; ?>
                                                                                <?php if($post->rss_image): ?>
                                                                                    <img data-src="<?php echo e($post->rss_image); ?>" alt="" class="lazy">
                                                                                <?php endif; ?>
                                                                                <?php if($post->post_type == 'audio'): ?>
                                                                                        <span  class="vid-aud">
                                                                                            <i class="fas fa-volume-up"></i>
                                                                                        </span>
                                                                                <?php endif; ?>
                                                                                <?php if($post->post_type == 'video'): ?>
                                                                                    <span  class="vid-aud">
                                                                                        <i class="fas fa-video"></i>
                                                                                    </span> 
                                                                                <?php endif; ?>
                                                                            <?php else: ?>
                                                                                <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                                            <?php endif; ?>
                                                                        </div>
                                                                        <div class="content">
                                                                            <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                                                <h4 class="title">
                                                                                    <?php echo e(strlen($post->title)>130 ? mb_substr($post->title,0,130,'utf-8').'...' : $post->title); ?>

                                                                                </h4>
                                                                            </a>
                                                                            <ul class="post-meta">
                                                                                <li>
                                                                                    <a href="<?php echo e(route('frontend.postByDate').'?date='.$post->created_at->format('Y-m-d')); ?>">
                                                                                        <?php echo e($post->createdAt()); ?>

                                                                                    </a>
                                                                                </li>
                                                                                <li>
                                                                                    <span>|</span>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="<?php echo e(route('front.authorProfile',$post->admin->name)); ?>">
                                                                                        <?php echo e($post->admin->name); ?>

                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>  
                                </div>
                            </div>
                            <!-- News Tabs End -->
                            <div class="row mb-5">
                                <div class="col-lg-12 mycol">
                                    <?php
                                        $index_bottom = advertisement(); //Method from helper.php class
                                    ?>

                                    <?php if($index_bottom): ?>
                                        <?php if($index_bottom->banner_type == 'image'): ?>
                                            <div class="add-long">
                                                <a href="<?php echo e($index_bottom->link); ?>" target="_blank" data-addid="<?php echo e($index_bottom->id); ?>" id="headerAdd">
                                                    <img data-src="<?php echo e(asset('assets/images/addBanner/'.$index_bottom->photo)); ?>" alt="" class="lazy">
                                                </a>
                                            </div>
                                        <?php else: ?> 
                                            <?php echo $header_ad->banner_code; ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php else: ?> 
                        <?php if($home_page_post->posts()->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->count()>0): ?>
                            <div class="main-content">
                                <div class="row">
                                    <div class="col-lg-12 mycol">
                                        <div class="header-area">
                                            <h3 class="title">
                                                <?php echo e($home_page_post->title); ?>

                                            </h3>
                                            <a class="view-all" href="<?php echo e(route('frontend.category',$home_page_post->slug)); ?>">
                                                <?php echo e(__('View all')); ?>

                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mycol">
                                        <?php $__currentLoopData = $home_page_post->posts()->orderBy('id','desc')->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->take(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="single-news landScape-normal">
                                                    <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                        <div class="content-wrapper">
                                                            <div class="img">
                                                                <?php if($post->image_big || $post->rss_image): ?>
                                                                    <div class="tag" style="background:<?php echo e($home_page_post->color); ?>">
                                                                        <?php echo e($post->category->title); ?>

                                                                    </div>
                                                                <?php endif; ?>
                                                                <?php if($post->image_big || $post->rss_image): ?>
                                                                    <?php if($post->image_big): ?>
                                                                        <img data-src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="" class="lazy">
                                                                    <?php endif; ?>
    
                                                                    <?php if($post->rss_image): ?>
                                                                        <img data-src="<?php echo e($post->rss_image); ?>" alt="" class="lazy">
                                                                    <?php endif; ?>
                                                                    <?php if($post->post_type == 'audio'): ?>
                                                                        <span  class="vid-aud">
                                                                            <i class="fas fa-volume-up"></i>
                                                                        </span>
                                                                    <?php endif; ?>
                                                                    <?php if($post->post_type == 'video'): ?>
                                                                        <span  class="vid-aud">
                                                                            <i class="fas fa-video"></i>
                                                                        </span> 
                                                                    <?php endif; ?>
                                                                <?php else: ?> 
                                                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="inner-content">
                                                                <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                                    <h4 class="title">
                                                                        <?php echo e(strlen($post->title)>170 ? mb_substr($post->title,0,170,'utf-8').'...' : $post->title); ?>

                                                                    </h4>
                                                                    <p class="text">
                                                                        <?php echo (strlen(convertUtf8(strip_tags($post->description))) > 400) ? convertUtf8(substr(strip_tags($post->description), 0, 400)) . '...' : convertUtf8(strip_tags($post->description)); ?> 
                                                                    </p>
                                                                    <ul class="post-meta">
                                                                        <li>
                                                                            <a href="<?php echo e(route('frontend.postByDate').'?date='.$post->created_at->format('Y-m-d')); ?>">
                                                                                <?php echo e($post->createdAt()); ?>

                                                                            </a>
                                                                        </li>
                                                                        <li>
                                                                            <span>|</span>
                                                                        </li>
                                                                        <li>
                                                                            <a href="<?php echo e(route('front.authorProfile',$post->admin->name)); ?>">
                                                                                <?php echo e($post->admin->name); ?>

                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="col-md-6 mycol">
                                        <?php $__currentLoopData = $home_page_post->posts()->orderBy('id','desc')->where('schedule_post','=',0)->where('status','=',true)->where('is_pending','=',0)->skip(1)->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                            <div class="single-box landScape-small-with-meta">
                                                <div class="img">
                                                    <?php if($post->image_big || $post->rss_image): ?>
                                                        <?php if($post->image_big): ?>
                                                            <img data-src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="" class="lazy">    
                                                        <?php endif; ?>
    
                                                        <?php if($post->rss_image): ?>
                                                            <img data-src="<?php echo e($post->rss_image); ?>" alt="" class="lazy">
                                                        <?php endif; ?>
    
                                                        <?php if($post->post_type == 'audio'): ?>
                                                            <span  class="vid-aud">
                                                                <i class="fas fa-volume-up"></i>
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php if($post->post_type == 'video'): ?>
                                                            <span  class="vid-aud">
                                                                <i class="fas fa-video"></i>
                                                            </span> 
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="content">
                                                    <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                        <h4 class="title">
                                                            <?php echo e(strlen($post->title)>130 ? mb_substr($post->title,0,130,'utf-8').'...' : $post->title); ?>

                                                        </h4>
                                                    </a>
                                                    <ul class="post-meta">
                                                        <li>
                                                            <a href="<?php echo e(route('frontend.postByDate').'?date='.$post->created_at->format('Y-m-d')); ?>">
                                                                <?php echo e($post->createdAt()); ?>

                                                            </a>
                                                        </li>
                                                        <li>
                                                            <span>|</span>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('front.authorProfile',$post->admin->name)); ?>">
                                                                <?php echo e($post->admin->name); ?>

                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-4 aside">
                <?php if($ws->feature_inhome == 1): ?>  
                    <div class="aside-tab mt-4">
                        <ul class="nav" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-tab1-tab" data-toggle="pill" href="#pills-tab1" role="tab" aria-controls="pills-tab1" aria-selected="true"><?php echo e(__('FEATURED')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-tab2-tab" data-toggle="pill" href="#pills-tab2" role="tab" aria-controls="pills-tab2" aria-selected="false"><?php echo e(__('RECENT')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-tab3-tab" data-toggle="pill" href="#pills-tab3" role="tab" aria-controls="pills-tab3" aria-selected="false"><?php echo e(__('TOP VIEWS')); ?></a>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-tab1" role="tabpanel" aria-labelledby="pills-tab1-tab">
                                <div class="row">
                                    <?php $__currentLoopData = $is_features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-12">
                                        <a href="<?php echo e(route('frontend.details',[$feature->id,$feature->slug])); ?>">
                                            <div class="single-box landScape-small-with-meta">
                                                <div class="img">
                                                    <?php if($feature->image_big || $feature->rss_image): ?>
                                                        <?php if($feature->image_big): ?>
                                                            <img data-src="<?php echo e(asset('assets/images/post/'.$feature->image_big)); ?>" alt="" class="lazy">
                                                        <?php endif; ?>
    
                                                        <?php if($feature->rss_image): ?>
                                                            <img data-src="<?php echo e($feature->rss_image); ?>" alt="" class="lazy">
                                                        <?php endif; ?>
    
                                                        <?php if($feature->post_type == 'audio'): ?>
                                                                <span  class="vid-aud">
                                                                    <i class="fas fa-volume-up"></i>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if($feature->post_type == 'video'): ?>
                                                                <span  class="vid-aud">
                                                                    <i class="fas fa-video"></i>
                                                                </span> 
                                                        <?php endif; ?>
                                                        
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="content">
                                                    <a href="<?php echo e(route('frontend.details',[$feature->id,$feature->slug])); ?>">
                                                        <h4 class="title">
                                                        <?php echo e(strlen($feature->title)>40 ? mb_substr($feature->title,0,40,"utf-8") : $feature->title); ?>

                                                        </h4>
                                                    </a>
                                                    <ul class="post-meta">
                                                        <li>
                                                            <a href="<?php echo e(route('frontend.postByDate').'?date='.$feature->created_at->format('Y-m-d')); ?>">
                                                                <?php echo e($feature->createdAt()); ?>

                                                            </a>
                                                        </li>
                                                        <li>
                                                            <span>|</span>
                                                        </li>
                                                        <li>
                                                            <a href="#">
                                                                <a href="<?php echo e(route('front.authorProfile',$feature->admin->name)); ?>">
                                                                    <?php echo e($feature->admin->name); ?>

                                                                </a>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-tab2" role="tabpanel" aria-labelledby="pills-tab2-tab">
                                <div class="row">
                                    <?php $__currentLoopData = $is_recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-12">
                                        <a href="<?php echo e(route('frontend.details',[$is_recent->id,$is_recent->slug])); ?>">
                                            <div class="single-box landScape-small-with-meta">
                                                <div class="img">
                                                    <?php if($is_recent->image_big || $is_recent->rss_image): ?>
                                                        <?php if($is_recent->image_big): ?>
                                                            <img data-src="<?php echo e(asset('assets/images/post/'.$is_recent->image_big)); ?>" alt="" class="lazy">
                                                        <?php endif; ?> 
    
                                                        <?php if($is_recent->rss_image): ?>
                                                            <img data-src="<?php echo e($is_recent->rss_image); ?>" alt="" class="lazy">
                                                        <?php endif; ?> 
    
                                                        <?php if($is_recent->post_type == 'audio'): ?>
                                                            <span  class="vid-aud">
                                                                <i class="fas fa-volume-up"></i>
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php if($is_recent->post_type == 'video'): ?>
                                                            <span  class="vid-aud">
                                                                <i class="fas fa-video"></i>
                                                            </span> 
                                                        <?php endif; ?>
    
                                                    <?php else: ?> 
                                                        <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="content">
                                                    <a href="<?php echo e(route('frontend.details',[$is_recent->id,$is_recent->slug])); ?>">
                                                        <h4 class="title">
                                                            <?php echo e(strlen($is_recent->title)>40 ? mb_substr($is_recent->title,0,40,"utf-8") : $is_recent->title); ?>

                                                        </h4>
                                                    </a>
                                                    <ul class="post-meta">
                                                        <li>
                                                            <a href="<?php echo e(route('frontend.postByDate').'?date='.$is_recent->created_at->format('Y-m-d')); ?>">
                                                                <?php echo e($is_recent->createdAt()); ?>

                                                            </a>
                                                        </li>
                                                        <li>
                                                            <span>|</span>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('front.authorProfile',$is_recent->admin->name)); ?>">
                                                                <?php echo e($is_recent->admin->name); ?>

                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-tab3" role="tabpanel" aria-labelledby="pills-tab3-tab">
                                <div class="row">
                                    <?php $__currentLoopData = $top_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $post = \App\Models\Post::where('id',$top_view->post_id)->where('language_id',$default_language->id)->first();
                                    ?>
                                        <?php if($post): ?>
                                            <div class="col-lg-12">
                                                <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                    <div class="single-box landScape-small-with-meta">
                                                        <?php if($post->image_big || $post->rss_image): ?>
                                                            <div class="img">
                                                                <?php if($post->image_big): ?>
                                                                    <img data-src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="" class="lazy">
                                                                <?php endif; ?>
                                                                <?php if($post->rss_image): ?>
                                                                    <img data-src="<?php echo e($post->rss_image); ?>" alt="" class="lazy">
                                                                <?php endif; ?>
                                                                <?php if($post->post_type == 'audio'): ?>
                                                                    <span  class="vid-aud">
                                                                        <i class="fas fa-volume-up"></i>
                                                                    </span>
                                                                <?php endif; ?>
                                                                <?php if($post->post_type == 'video'): ?>
                                                                    <span  class="vid-aud">
                                                                        <i class="fas fa-video"></i>
                                                                    </span> 
                                                                <?php endif; ?>
                                                            </div>
                                                        <?php else: ?> 
                                                            <div class="img">
                                                                <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="content">
                                                            <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                                <h4 class="title">
                                                                <?php echo e($post->title); ?>

                                                                </h4>
                                                            </a>
                                                            <ul class="post-meta">
                                                                <li>
                                                                    <a href="<?php echo e(route('frontend.postByDate').'?date='.$post->created_at->format('Y-m-d')); ?>">
                                                                        <?php echo e($post->createdAt()); ?>

                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <span>|</span>
                                                                </li>
                                                                <li>
                                                                    <a href="<?php echo e(route('front.authorProfile',$post->admin->name)); ?>">
                                                                        <?php echo e($post->admin->name); ?>

                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($ws->category_inhome == 1): ?>
                    <div class="categori-widget-area mt-4">
                        <div class="header-area">
                            <h4 class="title">
                                <?php echo e(__('CATEGORIES')); ?>

                            </h4>
                        </div>
                        <ul class="categori-list">
                            <?php $__currentLoopData = $home_page_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('frontend.category',$category->slug)); ?>">
                                    <span>
                                        <?php echo e($category->title); ?>

                                    </span>
                                    <span>
                                        (<?php echo e($category->posts()->where('schedule_post','=',0)->where('status','=',true)->count()); ?>)
                                    </span>
                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if($ws->follow_inhome == 1): ?>
                    <div class="social-follow-area">
                        <div class="header-area">
                            <h4 class="title">
                               <?php echo e(__('Follow Us')); ?>

                            </h4>
                        </div>
                        <ul class="social-links">
                            <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <li>
                                <a href="<?php echo e($social_link->link); ?>" class="<?php echo e($social_link->name); ?>">
                                    <i class="<?php echo e($social_link->icon); ?>"></i><?php echo e($social_link->name); ?>

                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if($ws->tag_inhome == 1): ?>
                    <div class="tags-widget">
                        <div class="header-area">
                            <h3 class="title">
                                <?php echo e(__('TAGS')); ?>

                            </h3>
                        </div>  
                        <ul class="tag-list">
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('tag.search',$tag)); ?>"><?php echo e($tag); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="add mt-4">
                    <?php
                    $sidebar_banner = sidebar_banner(); //method from helper.php class
                    ?>
                    <?php if($sidebar_banner): ?>
                        <?php if($sidebar_banner->banner_type == 'image'): ?>
                            <a href="<?php echo e($sidebar_banner->link); ?>">
                                <img data-src="<?php echo e(asset('assets/images/addBanner/'.$sidebar_banner->photo)); ?>" alt="" class="lazy">
                            </a>
                        <?php else: ?> 
                            <?php echo $sidebar_banner->banner_code; ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php if($ws->poll_inhome == 1): ?>
                    <div class="poll-area mt-4">
                        <div class="header-area">
                            <h4 class="title">
                               <?php echo e(__('Poll')); ?>

                            </h4>
                            <h5 class="title"><a href="<?php echo e(route('front.allPoll')); ?>" style="color: :#ff0000;"><?php echo e(__('Previous Result')); ?></a></h5>
                        </div> 

                        <?php $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="poll-box">
                            <h4 class="title">
                                <i class="far fa-question-circle"></i> <?php echo e($poll->question); ?>

                            </h4>
                            <form id="voteform<?php echo e($poll->id); ?>" action="<?php echo e(route('front.poll.vote')); ?>" method="POST" class="voteform">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="poll_question_id" value="<?php echo e($poll->id); ?>" id="poll_question_id">
                                <input type="hidden" name="ip_address">
                                <?php $__currentLoopData = $poll->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" id="customControlValidation<?php echo e($answer->id); ?>" name="poll_answer_id" value="<?php echo e($answer->id); ?>">
                                    <label class="custom-control-label" for="customControlValidation<?php echo e($answer->id); ?>"><?php echo e($answer->poll_option); ?></label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ip = request()->ip();
                                    $isVote = App\Models\PollResult::where('poll_question_id',$poll->id)->where('ip_address',$ip)->first();
                                ?>
                                <?php if(!$isVote): ?>
                                    <button data-id="<?php echo e($poll->id); ?>" type="submit" class="mybtn1 vote" id="vote_success-<?php echo e($poll->id); ?>"><?php echo e(__('Vote')); ?></button>
                                <?php else: ?>
                                    <button data-id="<?php echo e($poll->id); ?>" type="submit" class="mybtn1 result view_result" id="vote_view-<?php echo e($poll->id); ?>"><?php echo e(__('View Result')); ?></button>
                                <?php endif; ?>
                                <div class="viewVoteResult"></div>
                                <p id="errMsg"></p>
                                <div class="voteresult"></div>
                            </form>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if($ws->calendar_inhome == 1): ?>
                    <div class="celander-widget-area mt-4">
                        <div id="datecalender"></div>
                    </div>
                <?php endif; ?>
                <?php if($ws->newsletter_inhome == 1): ?>
                    <div class="aside-newsletter-widget mt-4 subarea">
                        <div class="header-area">
                            <h4 class="title">
                            <?php echo e(__('Newsletter')); ?>

                            </h4>
                        </div>
                        <p class="text"><?php echo e(__('Subscribe to our newsletter to stay.')); ?></p>
                        <form action="<?php echo e(route('front.subscribers.store')); ?>" class="subscribe-form" method="POST" id="subForm">
                            <?php echo csrf_field(); ?>
                            <input type="text" placeholder="<?php echo e(__('Enter Your Email Address')); ?>" name="email" class="subEmail">
                            <button type="submit" class="submit subBtn"><?php echo e(__('Subscribe')); ?></button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="video-gallery-box">
                    <div class="one-item-slider">
                        <video width="100%" height="435" controls>
                            <?php if(!empty($video_large)): ?>  
                                <source src="<?php echo e(asset('assets/videos/'.$video_large->video)); ?>" type="video/mp4">
                            <?php endif; ?>
                        </video>
                    </div>
                        <ul class="all-item-slider">
                            <?php $__currentLoopData = $video_smalls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video_small): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(asset('assets/videos/'.$video_small->video)); ?>" class="active">
                                        <div class="left">
                                            <img src="<?php echo e(asset('assets/images/post/'.$video_small->image_big)); ?>" alt="">
                                        </div>
                                        <div class="right">
                                            <h4 class="title">
                                                <?php echo e(strlen($video_small->title)>40 ? mb_substr($video_small->title,0,40,"utf-8").'...' : $video_small->title); ?>

                                            </h4>
                                            <p class="date">
                                                <?php echo e($video_small->createdAt()); ?>

                                            </p>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8">
                <?php if($is_features->count()>0): ?>
                <!-- Featured News Area Start -->
                <div class="featured-news">
                    <div class="row">
                        <div class="col-lg-12 mycol">
                            <div class="header-area">
                                <h3 class="title">
                                    <?php echo e(__('TODAYS FEATURED NEWS')); ?>

                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mycol">
                            <div class="feature-news-slider">
                                <?php $__currentLoopData = $is_features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <div class="single-news animation">
                                        <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                            <div class="content-wrapper">
                                                <?php if($post->image_big || $post->rss_image): ?>
                                                    <div class="tag" style="background:<?php echo e($post->category->color); ?>">
                                                        <?php echo e($post->category->title); ?>

                                                    </div>
                                                <?php endif; ?>
    
                                                <?php if($post->image_big || $post->rss_image): ?>
                                                    <?php if($post->image_big): ?>
                                                        <img data-src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="" class="lazy">
                                                    <?php endif; ?>
    
                                                    <?php if($post->rss_image): ?>
                                                        <img data-src="<?php echo e($post->rss_image); ?>" alt="" class="lazy">
                                                    <?php endif; ?>
                                                <?php else: ?> 
                                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                <?php endif; ?>
                                                <div class="inner-content">
                                                    <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                                        <h4 class="title">
                                                            <?php echo e(strlen($post->title)>30 ? mb_substr($post->title,0,30,'utf-8').'...' : $post->title); ?>

                                                        </h4>
                                                        <ul class="post-meta">
                                                            <li>
                                                                <a href="<?php echo e(route('frontend.postByDate').'?date='.$post->created_at->format('Y-m-d')); ?>">
                                                                    <?php echo e($post->createdAt()); ?>

                                                                </a>
                                                            </li>
                                                            <li>
                                                                <span>|</span>
                                                            </li>
                                                            <li>
                                                                <a href="<?php echo e(route('front.authorProfile',$post->admin->name)); ?>">
                                                                    <?php echo e($post->admin->name); ?>

                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </a>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Featured News Area End -->
                <?php endif; ?>

                <?php if($image_albums->count()>0): ?>
                <!-- Photo Gallery Area Start -->
                <div class="featured-news photos">
                        <div class="row">
                            <div class="col-lg-12 mycol">
                                <div class="header-area">
                                    <h3 class="title">
                                        <?php echo e(__('Image Gallery')); ?>

                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="gallery-images">
                                    <div class="row">
                                        <?php $__currentLoopData = $image_albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image_album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($image_album->categories)>0): ?>
                                                <div class="col-md-6 mycol">
                                                    <a href="<?php echo e(route('gallery.view',$image_album->id)); ?>" class="item">
                                                        <div class="single-news animation">
                                                            <div class="content-wrapper">
                                                                <img data-src="<?php echo e(asset('assets/images/image-album/'.$image_album->photo)); ?>" alt="" class="lazy">
                                                                <div class="inner-content">
                                                                    <h4 class="title">
                                                                        <?php echo e($image_album->album_name); ?>

                                                                    </h4>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- Photo Gallery Area End -->
                <?php endif; ?>

                <!-- More News Area Start -->
                <?php if($more_news->count()>0): ?>   
                    <div class="more-news">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="more-area">
                                    <div class="header-area">
                                        <h4 class="title">
                                            <?php echo e(__('More news')); ?>

                                        </h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 more">
                                        <?php $__currentLoopData = $more_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $more_new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('frontend.details',[$more_new->id,$more_new->slug])); ?>">
                                            <div class="single-news land-scap-medium">
                                                <div class="img">
                                                    <?php if($more_new->image_big || $more_new->rss_image): ?>
                                                        <div class="tag" style="background:<?php echo e($more_new->category->color); ?>">
                                                            <?php echo e($more_new->category->title); ?>

                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if($more_new->image_big || $more_new->rss_image): ?>
                                                        <?php if($more_new->image_big): ?>
                                                            <img data-src="<?php echo e(asset('assets/images/post/'.$more_new->image_big)); ?>" alt="" class="lazy">
                                                        <?php endif; ?>
                                                        <?php if($more_new->rss_image): ?>
                                                            <img data-src="<?php echo e($more_new->rss_image); ?>" alt="" class="lazy"> 
                                                        <?php endif; ?>
                                                        <?php if($more_new->post_type == 'audio'): ?>
                                                            <span  class="vid-aud">
                                                                <i class="fas fa-volume-up"></i>
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php if($more_new->post_type == 'video'): ?>
                                                            <span  class="vid-aud">
                                                                <i class="fas fa-video"></i>
                                                            </span> 
                                                        <?php endif; ?>
                                                    <?php else: ?>  
                                                        <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="content">
                                                    <a href="<?php echo e(route('frontend.details',[$more_new->id,$more_new->slug])); ?>">
                                                        <h4 class="title">
                                                            <?php echo e(strlen($more_new->title)>30 ? mb_substr($more_new->title,0,30,'utf-8').'...' : $more_new->title); ?>

                                                        </h4>
                                                        <p class="text">
                                                        <?php echo (strlen(convertUtf8(strip_tags($more_new->description))) > 200) ? convertUtf8(substr(strip_tags($more_new->description), 0, 200)) . '...' : convertUtf8(strip_tags($more_new->description)); ?>

                                                        </p>
                                                    </a>
                                                    <ul class="post-meta">
                                                        <li>
                                                            <a href="<?php echo e(route('frontend.postByDate').'?date='.$more_new->created_at->format('Y-m-d')); ?>">
                                                                <?php echo e($more_new->createdAt()); ?>

                                                            </a>
                                                        </li>
                                                        <li>
                                                            <span>|</span>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e(route('front.authorProfile',$more_new->admin->name)); ?>">
                                                                <?php echo e($more_new->admin->name); ?>

                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </a>
                                        <?php
                                            $last_id = $more_new->id;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 text-center mt-4">
                                    <button type="#" class="mybtn1" id="loadMore" data-id="<?php echo e($last_id); ?>"><?php echo e(__('Load More')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- More News Area End -->
            </div>
            <div class="col-lg-4 aside">
                <div class="add">
                    <div class="header-area">
                        <h4 class="title">
                        <?php echo e(__('Sponsor Ad')); ?>

                        </h4>
                    </div>
                    <?php $__currentLoopData = $sponsor_banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor_banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sponsor_banner): ?>
                            <?php if($sponsor_banner->banner_type == 'image'): ?>
                                <div class="add-banner mt-2">
                                    <a href="<?php echo e($sponsor_banner->link); ?>">
                                        <img data-src="<?php echo e(asset('assets/images/addBanner/1578288672add.jpg')); ?>" alt="" class="lazy">
                                    </a>
                                </div>
                            <?php else: ?> 
                                <?php echo $sponsor_banner->banner_code; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="widget-slider">
                    <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="aside-newsletter-widget mt-4">
                        <div class="header-area">
                            <h4 class="title">
                            <?php echo e($widget->title); ?>

                            </h4>
                        </div>
                        <p class="text"> <?php echo (strlen(convertUtf8(strip_tags($widget->description))) > 350) ? convertUtf8(substr(strip_tags($widget->description), 0, 350)) . '...' : convertUtf8(strip_tags($widget->description)); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
</section>
<!-- Home Front Area End -->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        "use strict";

        var lang = {
            'load_more': '<?php echo e(__('Load More')); ?>',
            'hide_resultt': '<?php echo e(__('Hide Result')); ?>',
            'view_resultt': '<?php echo e(__('View Result')); ?>',
            'loading': '<?php echo e(__('Loading......')); ?>',
        }
    </script>
    <script src="<?php echo e(asset('assets/front/js/notify.min.js')); ?>"></script>
    <script id="dsq-count-scr" src="//<?php echo e($gs->disqus); ?>.disqus.com/count.js" async></script>
    <script src="<?php echo e(asset('assets/front/js/front.js')); ?>"></script>

    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.9/jquery.lazy.plugins.min.js"></script> 
    <script>
        "use strict";	
        $(function() {
            $('.lazy').Lazy();
        });
    </script>
    
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newspaper\project\resources\views/frontend/index.blade.php ENDPATH**/ ?>