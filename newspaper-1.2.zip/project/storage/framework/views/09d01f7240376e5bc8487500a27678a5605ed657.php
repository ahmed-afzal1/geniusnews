<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php if(request()->is('details/*')): ?>
	<?php if($data->meta_tag && $data->tags): ?>
		<meta name="description" content="<?php echo e($data->meta_tag); ?>">
		<meta name="keywords" content="<?php echo e($data->tags); ?>">
	<?php endif; ?>
	<?php endif; ?>
	<?php if($gs->title): ?>
		<title> <?php echo e($gs->title); ?></title>
	<?php endif; ?>

	<?php if($default_font->font_value): ?>
		<link href="https://fonts.googleapis.com/css?family=<?php echo e($default_font->font_value); ?>&display=swap" rel="stylesheet">
	<?php else: ?> 
		<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
	<?php endif; ?>
	<!-- favicon -->
	<link rel="shortcut icon" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>" type="image/x-icon">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>">
	<!-- Plugin css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/plugin.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/go-masonry.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/magnific-popup.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/pignose.calender.css')); ?>">
	<!-- stylesheet -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.css')); ?>">
	<!-- custom stylesheet -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/custom.css')); ?>">
	<!-- responsive -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/responsive.css')); ?>">
	

	<?php if(DB::table('languages')->where('is_default','=',1)->first()->rtl == 1): ?>
		<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/rtl/style.css')); ?>">
	<?php endif; ?>
	<link rel="stylesheet" id="color" href="<?php echo e(asset('assets/front/css/color.php?base_color='.str_replace('#','', $gs->theme_color).'&'.'footer_color='.str_replace('#','',$gs->footer_color).'&'.'copyright_color='.str_replace('#','',$gs->copyright_color))); ?>">
	<link rel="stylesheet" id="color" href="<?php echo e(asset('assets/front/css/font.php?font_familly='.$default_font->font_family)); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>

    <!-- Header Part-->
    <?php echo $__env->make('partial.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header Part End-->

    <!--Content of each page-->
    <?php echo $__env->yieldContent('contents'); ?>
	<!--Content of each page end-->

	<!-- Footer Area Start -->
	<?php echo $__env->make('partial.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Footer Area End -->

	<!-- Back to Top Start -->
	<div class="bottomtotop">
		<i class="fas fa-chevron-right"></i>
	</div>
	<!-- Back to Top End -->
	
	<script>
		var mainurl = "<?php echo e(url('/')); ?>/";
		var gs      = "<?php echo e($gs); ?>";
	</script>
	
	<!-- jquery -->
	<script src="<?php echo e(asset('assets/front/js/jquery.js')); ?>"></script>
	<!-- bootstrap -->
	<script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
	<!-- popper -->
	<script src="<?php echo e(asset('assets/front/js/popper.min.js')); ?>"></script>
	<!-- Calender Js -->
	<script src="<?php echo e(asset('assets/front/js/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/pignose.calender.js')); ?>"></script>
	<!-- plugin js-->
	<script src="<?php echo e(asset('assets/front/js/plugin.js')); ?>"></script>
	
	<script src="<?php echo e(asset('assets/front/js/jquery.unveil.js')); ?>"></script>
	<!-- main -->
	<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>
	
	<script src="<?php echo e(asset('assets/front/js/custom.js')); ?>"></script>
	
	

	<script>
		function updateClock ( ){
			var currentTime = new Date ( );
			var currentHours = currentTime.getHours ( );
			var currentMinutes = currentTime.getMinutes ( );
			var currentSeconds = currentTime.getSeconds ( );
			// Pad the minutes and seconds with leading zeros, if required
			currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
			currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
			// Choose either "AM" or "PM" as appropriate
			var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";
			// Convert the hours component to 12-hour format if needed
			currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
			// Convert an hours component of "0" to "12"
			currentHours = ( currentHours == 0 ) ? 12 : currentHours;
			// Compose the string for display
			var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;
			$(".time-now").html(currentTimeString);
		}

		$(document).ready(function()
		{
			setInterval('updateClock()', 1000);
		});
	</script>
	
    <?php echo $__env->yieldPushContent('js'); ?>

</body>

</html><?php /**PATH F:\xampp\htdocs\New folder\newspaper\newspaper\project\resources\views/layouts/front.blade.php ENDPATH**/ ?>