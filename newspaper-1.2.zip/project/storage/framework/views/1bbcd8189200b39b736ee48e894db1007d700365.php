

<?php $__env->startSection('content'); ?>

<div class="add-product-content p-0 shadow-none">
    <div class="row">
        <div class="col-lg-12">
            <div class="product-description">
                <div class="body-area shadow-none">
                    <?php echo $__env->make('includes.admin.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                    <form id="geniusformdata" action="<?php echo e(route('subcategories.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Language')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <select name="language_id" id="article_language_id">
                                    <option value=""><?php echo e(__('Please Select Your Language')); ?></option>
                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($data->id); ?>"><?php echo e($data->language); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Parent Category')); ?> *</h4>
                                    <p class="sub-heading"><?php echo e(__('In English')); ?></p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <select name="parent_id" id="article_parent_id">
                                    <option value=""><?php echo e(__('Please select a category')); ?></option>
                                </select>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-lg-12">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Title')); ?> *</h4>
                                    <p class="sub-heading"><?php echo e(__('(In Any Language)')); ?></p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <input type="text" class="input-field" name="title"
                                    placeholder="<?php echo e(__('Title')); ?>">
                            </div>
                        </div>

                        <input type="hidden" class="input-field" name="slug" placeholder="<?php echo e(__('Slug')); ?>">


                        <div class="row">
                            <div class="col-lg-4">
                                <div class="left-area">
                                    <h4 class="heading"><?php echo e(__('Show At Menu')); ?> *</h4>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <div class="custom-control custom-radio d-inline-block mr-4">
                                    <input type="radio" class="custom-control-input" id="yes" name="show_on_menu" value="1">
                                    <label class="custom-control-label" for="yes"><?php echo e(__('Yes')); ?></label>
                                </div>
                                <div class="custom-control custom-radio d-inline-block">
                                    <input type="radio" class="custom-control-input" id="no" name="show_on_menu" value="0" checked> 
                                    <label class="custom-control-label" for="no"><?php echo e(__('No')); ?></label>
                                </div>
                            </div>
                        </div>
                        
                        <br>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="left-area">

                                </div>
                            </div>
                            <div class="col-lg-7">
                                <button class="addProductSubmit-btn"
                                    type="submit"><?php echo e(__('Create Sub Category')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/admin/js/articleCreate.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\newspaper\project\resources\views/admin/subcategory/create.blade.php ENDPATH**/ ?>