


<?php $__env->startSection('contents'); ?>

<!-- Breadcrumb Area Start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="pages">
                    <li>
                        <a href="#">
                            <?php echo e(__('Login & Register')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <a href="#">
                            <?php echo e(__('Login & Register')); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Area Start -->

<!-- Log & Register Area Start -->
<section class="login-signup">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <nav class="comment-log-reg-tabmenu core-nav">
                    <div class="full-container">
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link login active" id="nav-log-tab" data-toggle="tab" href="#nav-log"
                                role="tab" aria-controls="nav-log" aria-selected="true">
                                <?php echo e(__('Login')); ?>

                            </a>
                            <a class="nav-item nav-link" id="nav-reg-tab" data-toggle="tab" href="#nav-reg" role="tab"
                                aria-controls="nav-reg" aria-selected="false">
                                <?php echo e(__('Register')); ?>

                            </a>
                        </div>
                    </div>
                </nav>
                <div class="dropdown-overlay"></div>
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-log" role="tabpanel" aria-labelledby="nav-log-tab">
                        <div class="login-area">
                            <div class="log-reg-header-area">
                                <h4 class="title"><?php echo e(__('LOGIN NOW')); ?></h4>
                            </div>
                            <div class="login-form signin-form">
                                <form class="mloginform" action="<?php echo e(route('front.login')); ?>" method="POST">
                                    <?php echo $__env->make('includes.validation.form_validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="form-input">
                                        <input type="email" name="email" value=""
                                            placeholder="<?php echo e(__('Type Email Address')); ?>" required="">
                                        <i class="icofont-user-alt-5"></i>
                                    </div>
                                    <div class="form-input">
                                        <input type="password" class="Password" value="" name="password"
                                            placeholder="<?php echo e(__('Type Password')); ?>" required="">
                                        <i class="icofont-ui-password"></i>
                                    </div>
                                    <div class="form-forgot-pass">
                                        <div class="left">
                                            <input type="checkbox" name="remember" id="mrp">
                                            <label for="mrp"><?php echo e(__('Remember Password')); ?></label>
                                        </div>
                                        <div class="right">
                                            <a href="<?php echo e(route('front.forgot')); ?>">
                                                <?php echo e(__('Forgot Password')); ?>?
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <input class="mauthdata" type="hidden" value="Authenticating...">
                                    <button type="submit" class="submit-btn"><?php echo e(__('Login')); ?></button>
                                    <div class="log-reg-social-area">
                                        <h3 class="title"><?php echo e(__('Or')); ?></h3>
                                        <p class="text"><?php echo e(__('Sign In with social media')); ?></p>
                                        <ul class="log-reg-social-links">
                                            <li>
                                                <a href="<?php echo e(route('social.provider','facebook')); ?>">
                                                    <i class="fab fa-facebook-f"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('social.provider','google')); ?>">
                                                    <i class="fab fa-google-plus-g"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-reg" role="tabpanel" aria-labelledby="nav-reg-tab">
                        <div class="login-area signup-area">
                            <div class="log-reg-header-area">
                                <h4 class="title"><?php echo e(__('Signup Now')); ?></h4>
                            </div>
                            <div class="login-form signup-form">
                                <?php echo $__env->make('includes.validation.form_validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form class="registerform" action="<?php echo e(route('front.register')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-input">
                                        <input type="text" class="User Name" name="name" placeholder="<?php echo e(__('Full Name')); ?>"
                                            required="">
                                        <i class="icofont-user-alt-5"></i>
                                    </div>

                                    <div class="form-input">
                                        <input type="email" class="User Name" name="email" placeholder="<?php echo e(__('Email Address')); ?>"
                                            required="">
                                        <i class="icofont-email"></i>
                                    </div>

                                    <div class="form-input">
                                        <input type="text" class="User Name" name="phone" placeholder="<?php echo e(__('Phone Number')); ?>"
                                            required="">
                                        <i class="icofont-phone"></i>
                                    </div>

                                    <div class="form-input">
                                        <input type="password" class="Password" name="password" placeholder="<?php echo e(__('Password')); ?>"
                                            required="">
                                        <i class="icofont-ui-password"></i>
                                    </div>

                                    <div class="form-input">
                                        <input type="password" class="Password" name="password_confirmation"
                                            placeholder="<?php echo e(__('Confirm Password')); ?>" required="">
                                        <i class="icofont-ui-password"></i>
                                    </div>


                                    <ul class="captcha-area">
                                        <li>
                                            <p><img class="codeimg1"
                                                    src="<?php echo e(asset("assets/images/capcha_code.png")); ?>"
                                                    alt=""> <i class="fas fa-sync-alt pointer refresh_code"></i></p>
                                        </li>
                                    </ul>

                                    <div class="form-input">
                                        <input type="text" class="Password" name="codes" placeholder="<?php echo e(__('Enter Code')); ?>"
                                            required="">
                                        <i class="icofont-refresh"></i>
                                    </div>

                                    <input class="mregdata" type="hidden" value="Registering...">
                                    <button type="submit" class="submit-btn"><?php echo e(__('Register')); ?></button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</section>
<!-- Log & Register Area End -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/front/js/login.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\htdocs\newspaper-1.1\project\resources\views/frontend/log-reg.blade.php ENDPATH**/ ?>