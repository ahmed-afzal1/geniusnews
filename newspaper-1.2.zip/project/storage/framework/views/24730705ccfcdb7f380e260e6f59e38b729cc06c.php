

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('contents'); ?>
    	<!-- Breadcrumb Area Start -->
	<div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="pages">
                        <li>
                            <a href="#">
                                <?php echo e(__('Home')); ?>

                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <?php echo e(__('News')); ?>

                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('frontend.category',$parent->slug)); ?>">
                                <?php echo e($parent->title); ?>

                            </a>
                        </li>
                        <li class="active">
                            <a href="#">
                                <?php echo e($subcategory); ?>

                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
</div>
<!-- Breadcrumb Area Start -->

<!-- Categori Page Start -->
<section class="categori-page-news">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="categoti-content-area">
                    <div class="row">
                        <?php if($datas->count()>0): ?>
                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 mycol">
                                    <div class="single-news animation">
                                        <a href="<?php echo e(route('frontend.postBySubcategory.details',[$post->category->slug,$post->slug])); ?>">
                                            <div class="content-wrapper">
                                                <div class="tag">
                                                    <?php echo e($subcategory); ?>

                                                </div>
                                                <?php if($post->image_big || $post->rss_image): ?>
                                                    <?php if($post->image_big): ?>
                                                        <img src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="">
                                                    <?php endif; ?>
                                                <?php if($post->rss_image): ?>
                                                    <img src="<?php echo e($post->rss_image); ?>" alt="">
                                                <?php endif; ?>
    
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
                                                <?php endif; ?>
                                                <div class="inner-content">
                                                    <a href="<?php echo e(route('frontend.postBySubcategory.details',[$post->category->slug,$post->slug])); ?>">
                                                        <h4 class="title">
                                                            <?php echo e(strlen($post->title)>50 ? mb_substr($post->title,0,50,'utf-8').'...' : $post->title); ?>

                                                        </h4>
                                                        <ul class="post-meta">
                                                            <li>
                                                                <a href="#">
                                                                    <?php echo e($post->createdAt()); ?>

                                                                </a>
                                                            </li>
                                                            <li>
                                                                <span>|</span>
                                                            </li>
                                                            <li>
                                                                <a href="#">
                                                                    <?php echo e($post->admin->name); ?>

                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </a>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?> 
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <p class="text-danger text-danger text-center"><?php echo e(__('This Sub Category has no News.')); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 aside">
                <div class="categori-widget-area">
                    <div class="header-area">
                        <h4 class="title">
                               <?php echo e(__(' CATEGORIES')); ?>

                        </h4>
                    </div>
                    <ul class="categori-list">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <li>
                                <a href="<?php echo e(route('frontend.category',$category->slug)); ?>">
                                    <span>
                                        <?php echo e($category->title); ?>

                                    </span>
                                    <span>
                                        (<?php echo e($category->posts()->where('schedule_post','=',0)->where('status','=',true)->count()); ?>)
                                    </span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="aside-newsletter-widget mt-3 subarea">
                    <h4 class="title"><?php echo e(__('Newsletter')); ?></h4>
                    <p class="text"><?php echo e(__('Subscribe to our newsletter to stay.')); ?></p>
                    <form action="<?php echo e(route('front.subscribers.store')); ?>" class="subscribe-form" method="POST" id="subForm>
                        <?php echo csrf_field(); ?>
                        <input type="text" placeholder="<?php echo e(__('Enter Your Email Address')); ?>" name="email" class="subEmail">
                        <button type="submit" class="submit subBtn"><?php echo e(__('Subscribe')); ?></button>
                    </form>
                </div>
                <div class="celander-widget-area mt-4">
                        <div id="datecalender">
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- More News Area End -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('assets/front/js/notify.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/rfront.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\mamp\htdocs\newspaper-1.1\project\resources\views/frontend/postBySubcategory.blade.php ENDPATH**/ ?>