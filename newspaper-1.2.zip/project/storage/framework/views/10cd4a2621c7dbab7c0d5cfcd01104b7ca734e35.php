	<!--Main-Menu Area Start-->

		<!-- preloader area start -->
		<div class="preloader" id="preloader">
			<div class="loader loader-1">
				<div class="loader-outter"></div>
				<div class="loader-inner"></div>
			</div>
		</div>
		<!-- preloader area end -->
	
		<!-- Top Header Area Start -->
		<section class="main-top-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 align-self-center">
						<div class="top-header-content">
							<div class="left-content">
								<ul class="list">

									<?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
									<li>
										<a href="<?php echo e($social_link->link); ?>" class="<?php echo e($social_link->name); ?>">
											<i class="<?php echo e($social_link->icon); ?>"></i>
										</a>
									</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
							<div class="right-content">
								<div class="list">
									<?php if(Auth::guard('admin')->user() && Auth::guard('admin')->user()->role_id != 1): ?>
									<?php else: ?> 
										<li class="log-reg">
										<a href="<?php echo e(route('front.LogReg')); ?>"><?php echo e(__('Login')); ?></a>
											<span>
												/
											</span>
											<a href="<?php echo e(route('front.LogReg')); ?>"><?php echo e(__('Register')); ?></a>
										</li>
									<?php endif; ?>
									<?php if(Auth::guard('admin')->user() && Auth::guard('admin')->user()->role_id != 1): ?>
									     <?php
											 $data = Auth::guard('admin')->user();
										 ?>
										<li class="user-profile">
											<div class="nav-item dropdown">
												<a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													<img src="<?php echo e($data->photo ? asset('assets/images/admin/'.$data->photo):asset('assets/images/noimage.png')); ?>" alt="">
												</a>
												<ul class="dropdown-menu">
												<li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>"><i class="far fa-user-circle"></i><?php echo e(__('Dashboard')); ?></a></li>
												<li><a class="dropdown-item" href="<?php echo e(route('front.logout')); ?>"><i class="fas fa-sign-out-alt"></i><?php echo e(__('Logout')); ?></a></li>
												</ul>
											</div>
										</li>
									<?php endif; ?>
									<li>
										<select id="languageChange">
											<?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($language->id); ?>" <?php echo e(Session::has('language') ? ( Session::get('language') == $language->id ? 'selected' : '' ) : (DB::table('languages')->where('is_default','=',1)->first()->id == $language->id ? 'selected' : '')); ?>><?php echo e($language->language); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</li>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Top Header Area End -->

		<!-- Logo Header Area Start -->
		<section class="logo-header"> 
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-4 d-flex align-self-center">
						<a class="navbar-brand" href="<?php echo e(route('frontend.index')); ?>">
							<?php
								Session::has('language') ? $lid=Session::get('language') : $lid = (DB::table('languages')->where('is_default','=',1)->first()->id)
							?>
							
							<?php
								$header_footer_logo = d_logo($lid);
							?>
							
							<?php if(!empty($header_footer_logo[0]->header_logo)): ?>
								<img src="<?php echo e($header_footer_logo[0]->header_logo ? asset('assets/images/logo/'.$header_footer_logo[0]->header_logo) : asset('assets/front/images/logo.png')); ?>" alt="">
							<?php else: ?>
								<img src="<?php echo e($gs->logo ? asset('assets/images/logo/'.$gs->logo) : asset('assets/front/images/logo.png')); ?>" alt="">
							<?php endif; ?>
						</a>
					</div>
					<div class="col-lg-8 col-md-8 align-self-center">
						<?php
							$header_ad = header_ads();
						?>
						<?php if($header_ad): ?>
							<?php if($header_ad->banner_type == 'image'): ?>
								<div class="add-banner">
									<a href="<?php echo e($header_ad->link); ?>"><img src="<?php echo e(asset('assets/images/addBanner/'.$header_ad->photo)); ?>" alt=""></a>
								</div>
							<?php else: ?> 
								<div class="add-banner">
									<?php echo $header_ad->banner_code; ?>

								</div>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</section>
		<!-- Logo Header Area End -->
	
		<!--Main-Menu Area Start-->
		<div class="mainmenu-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="navsm">
							<div class="toogle-icon">
								<i class="fas fa-bars"></i>
							</div>
	
							<div class="serch-icon web-serch">
								<i class="fas fa-search"></i>
							</div>
							<div class="search-form-area">
								<form class="search-form" action="#">
									<input type="text" name="search" placeholder="Search what you want">
								</form>
							</div>
						</div>
						<nav class="navbar navbar-expand-lg navbar-light menulg">
							<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_menu"
								aria-controls="main_menu" aria-expanded="false" aria-label="Toggle navigation">
								<span class="navbar-toggler-icon"></span>
							</button>
							<style>
								.go-tab-c {
									display: none;
								}
								.go-tab-c.active {
									display: block !important;
								}
							</style>
							<div class="collapse navbar-collapse fixed-height" id="main_menu">
								<ul class="navbar-nav mr-auto">
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($loop->first): ?>
											<li class="nav-item">
												<a class="nav-link <?php echo e($loop->first ? 'active' : ' '); ?>" href="<?php echo e(route('frontend.index')); ?>">
													<?php echo e($category->title); ?></a>
											</li>
										<?php endif; ?>
										
										<?php if($category->child()->count() > 0): ?>
											<li class="nav-item dropdown mega-menu">
													<a class="nav-link dropdown-toggle" href="<?php echo e(route('frontend.category',$category->slug)); ?>">
														<?php echo e($category->title); ?>

												</a>
												<div class="dropdown-menu">
													<div class="row m-0 p-0">
														<div class="col-lg-2 p-0">
															<div class="nav flex-column">
																<?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<a class="nav-link tab-link"  href="<?php echo e(route('frontend.postBySubcategory',[$category->slug,$child->slug])); ?>" data-tab="
																	#<?php echo e($child->id); ?>" ><?php echo e($child->title); ?> </a>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</div>  
														</div>
													<div class="col-lg-10">
														<div class="tab-content">
															<?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<div id="<?php echo e($child->id); ?>" class="go-tab-c <?php echo e($loop->first ? 'active' : ''); ?>" >
																	<?php if(count($child->subcategoryPosts)>0): ?>
																	<div class="row">
																		<?php $__currentLoopData = $child->subcategoryPosts()->latest()->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																			<div class="col-lg-3 col-md-4 col-sm-6 pr-0">
																				<div class="single-news-menu">
																					<div class="content-wrapper">
																						<div class="img">
																							<?php if($post->image_big || $post->rss_image): ?>
																								<div class="tag" style="background:<?php echo e($child->color); ?>">
																									<?php echo e($child->title); ?>

																								</div>
																							<?php endif; ?>
																							<?php if($post->image_big || $post->rss_image): ?>
																								<?php if($post->image_big): ?>
																									<img src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt=""> 
																								<?php endif; ?>
																								<?php if($post->rss_image): ?>
																									<img src="<?php echo e($post->rss_image); ?>" alt="">
																								<?php endif; ?>
																								<?php if($post->post_type == 'audio'): ?>
																									<span  class="vid-aud">
																										<i class="fas fa-volume-up"></i>
																									</span>
																								<?php endif; ?>
																								<?php if($post->post_type == 'video'): ?>
																									<span  class="vid-aud">
																										<i class="fas fa-video"></i>
																									</span> 
																								<?php endif; ?>
																							<?php else: ?> 
																								<img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
																							<?php endif; ?>
																						</div>
																						<div class="inner-content">
																							<a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
																								<h4 class="title">
																									<?php echo e(strlen($post->title)>40 ? mb_substr($post->title,0,40,'utf-8').'...' : $post->title); ?>

																								</h4>
																								<ul class="post-meta">
																									<li>
																										<span href="#">
																											<?php echo e($post->createdAt()); ?>

																										</span>
																									</li>
																									<li>
																										<span>|</span>
																									</li>
																									<li>
																										<span href="#">
																											<?php echo e($post->admin->name); ?>

																										</span>
																									</li>
																								</ul>
																							</a>
																						</div>
																					</div>
																				</div>
																			</div>
																		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																		</div>
																	<?php endif; ?>
																</div>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</div>
													</div>
													</div>
												</div>
											</li>
										<?php else: ?>
											<?php if($loop->first): ?>
											<?php else: ?> 
												<li class="nav-item">
													<a class="nav-link" href="<?php echo e(route('frontend.category',$category->slug)); ?>"><?php echo e($category->title); ?></a>
												</li>
											<?php endif; ?>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									
								</ul>
							</div>
							<div class="serch-icon-area">
								<p class="web-serch">
									<i class="fas fa-search"></i>
								</p>
							</div>
							<div class="search-form-area">
								<form class="search-form" action="<?php echo e(route('front.news_search')); ?>" method="get">
									<input type="text" name="search" placeholder="<?php echo e(__('Search what you want')); ?>">
								</form>
							</div>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<!--Main-Menu Area Start-->
	
		<!-- Mobile Menu Area Start -->
		<div class="mobile-menu">
			<div class="logo-area">
				<a class="navbar-brand" href="<?php echo e(route('frontend.index')); ?>">
					<img src="<?php echo e($gs->logo ? asset('assets/images/logo/'.$gs->logo) : asset('assets/front/images/logo.png')); ?>" alt="">
				</a>
				<div class="close-menu">
					<i class="fas fa-times"></i>
				</div>
			</div>
			<ul class="mobile-menu-list">
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($loop->first): ?>
					<li class="nav-item">
						<a class="nav-link <?php echo e($loop->first ? 'active' : ' '); ?>" href="<?php echo e(route('frontend.index')); ?>">
							<?php echo e($category->title); ?></a>
					</li>
				<?php endif; ?>
				
				<?php if($category->child()->count() > 0): ?>
					<li class="nav-item dropdown mega-menu">
							<a class="nav-link dropdown-toggle" href="<?php echo e(route('frontend.category',$category->slug)); ?>">
								<?php echo e($category->title); ?>

						</a>
						<div class="dropdown-menu">
							<div class="row m-0 p-0">
								<div class="col-lg-2 p-0">
									<div class="nav flex-column">
										<?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<a class="nav-link tab-link"  href="<?php echo e(route('frontend.postBySubcategory',[$category->slug,$child->slug])); ?>" data-tab="
											#<?php echo e($child->id); ?>" ><?php echo e($child->title); ?> </a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>  
								</div>
							<div class="col-lg-10">
								<div class="tab-content">
									<?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div id="<?php echo e($child->id); ?>" class="go-tab-c <?php echo e($loop->first ? 'active' : ''); ?>" >
											<?php if(count($child->subcategoryPosts)>0): ?>
											<div class="row">
												<?php $__currentLoopData = $child->subcategoryPosts()->latest()->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="col-lg-3 col-md-4 col-sm-6 pr-0">
														<div class="single-news-menu">
															<div class="content-wrapper">
																<div class="img">
																	<?php if($post->image_big || $post->rss_image): ?>
																		<div class="tag" style="background:<?php echo e($child->color); ?>">
																			<?php echo e($child->title); ?>

																		</div>
																	<?php endif; ?>
																	<?php if($post->image_big || $post->rss_image): ?>
																		<?php if($post->image_big): ?>
																			<img src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt=""> 
																		<?php endif; ?>

																		<?php if($post->rss_image): ?>
																			<img src="<?php echo e($post->rss_image); ?>" alt="">
																		<?php endif; ?>
																		<?php if($post->post_type == 'audio'): ?>
																			<span  class="vid-aud">
																				<i class="fas fa-volume-up"></i>
																			</span>
																		<?php endif; ?>
																		<?php if($post->post_type == 'video'): ?>
																			<span  class="vid-aud">
																				<i class="fas fa-video"></i>
																			</span> 
																		<?php endif; ?>
																	<?php else: ?> 
																		<img src="<?php echo e(asset('assets/images/nopic.png')); ?>" alt="">
																	<?php endif; ?>
																</div>
																<div class="inner-content">
																	<a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
																		<h4 class="title">
																			<?php echo e(strlen($post->title)>40 ? mb_substr($post->title,0,40,'utf-8').'...' : $post->title); ?>

																		</h4>
																		<ul class="post-meta">
																			<li>
																				<span href="#">
																					<?php echo e($post->createdAt()); ?>

																				</span>
																			</li>
																			<li>
																				<span>|</span>
																			</li>
																			<li>
																				<span href="#">
																					<?php echo e($post->admin->name); ?>

																				</span>
																			</li>
																		</ul>
																	</a>
																</div>
															</div>
														</div>
													</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
											<?php endif; ?>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
							</div>
						</div>
					</li>
				<?php else: ?>
					<?php if($loop->first): ?>
					<?php else: ?> 
						<li class="nav-item">
							<a class="nav-link" href="<?php echo e(route('frontend.category',$category->slug)); ?>"><?php echo e($category->title); ?></a>
						</li>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
			</ul>
		</div>
		<!-- Mobile Menu Area End -->
	

<?php /**PATH /home/junnuns/public_html/newspaper/project/resources/views/partial/front/header.blade.php ENDPATH**/ ?>