<footer class="footer" id="footer">
    <div class="container">
        <div class="row">

        </div>
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="footer-widget about-widget">
                    <div class="footer-logo">
                        <a href="<?php echo e(route('frontend.index')); ?>">
                            <?php
								Session::has('language') ? $lid=Session::get('language') : $lid = (DB::table('languages')->where('is_default','=',1)->first()->id)
							?>
							
                            <?php
                                $header_footer_logo = d_logo($lid);
                            ?>
                            
                            <?php if(!empty($header_footer_logo[0]->footer_logo)): ?>
                                <img src="<?php echo e($header_footer_logo[0]->footer_logo ? asset('assets/images/logo/'.$header_footer_logo[0]->footer_logo) : asset('assets/front/images/logo.png')); ?>" alt="">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/logo/'.$gs->logo)); ?>" alt="">
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="text">
                        <p>
                            <?php echo strlen($gs->footer_text)>167 ? substr($gs->footer_text,0,166):$gs->footer_text; ?>

                        </p>
                    </div>
                    <div class="social-links">
                        <h4 class="title">
                            <?php echo e(__('Follow Us')); ?>:
                        </h4>
                    </div>
                </div>
                <div class="fotter-social-links">
                    <ul>
                        <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e($social_link->link); ?>" class="<?php echo e($social_link->name); ?> mb-2">
                                    <i class="<?php echo e($social_link->icon); ?>"></i>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-lg-2">
                <div class="footer-widget info-link-widget ilw1">
                    <h4 class="title">
                        <?php echo e(__('CATEGORIES')); ?>

                    </h4>
                    <ul class="link-list">
                        <?php $__currentLoopData = $default_language->categories()->inRandomOrder()->limit(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <li>
                                <a href="<?php echo e(route('frontend.category',$category->slug)); ?>">
                                    <span>
                                        <?php echo e($category->title); ?>

                                    </span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="footer-widget blog-widget">
                    <h4 class="title">
                        <?php echo e(__('Popular Post')); ?>

                    </h4>
                    
                    <ul class="post-list">
                        <?php $__currentLoopData = $top_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $post = \App\Models\Post::where('id',$top_view->post_id)->where('language_id',$default_language->id)->first();
                            ?>
                          <?php if($post): ?> 
                            <li>
                                <div class="post">
                                    <div class="post-img">
                                        <?php if($post->image_big): ?>
                                            <div class="img">
                                                <img src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" alt="">
                                            </div>
                                        <?php else: ?> 
                                            <div class="img">
                                                <img src="<?php echo e($post->rss_image); ?>" alt="">
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="post-details">
                                        <a href="<?php echo e(route('frontend.details',[$post->id,$post->slug])); ?>">
                                            <h4 class="post-title">
                                                <?php echo e(strlen($post->title)>30 ? mb_substr($post->title,0,30,'utf-8').'...' : $post->title); ?>

                                            </h4>
                                        </a>
                                    </div>
                                </div>
                            </li>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="footer-widget tags-widget">
                    <h4 class="title">
                        <?php echo e(__('TAGS')); ?>

                    </h4>
                    <ul class="tag-list">
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('tag.search',$tag)); ?>">
                                    <?php echo e($tag); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="copy-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="content">
                        <div class="content">
                            <p><a href="<?php echo e(route('frontend.index')); ?>"><?php echo e($gs->copyright_text); ?></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="content">
                        <div class="content footerMenu">
                            <ul class="nav">
                                <?php
                                    $footer_menus = \App\Models\Page::where('placement','footer')->where('status',1)->get();
                                ?>
                                <?php $__currentLoopData = $footer_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('dynamic.page',$menu->slug)); ?>"><?php echo e($menu->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH F:\xampp\htdocs\newspaper\newspaper\project\resources\views/partial/front/footer.blade.php ENDPATH**/ ?>