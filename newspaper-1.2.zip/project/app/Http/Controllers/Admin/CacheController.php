<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Artisan;

class CacheController extends Controller
{
  public function __construct()
  {
      $this->middleware('auth:admin');
  }

  public function clear() {
      Artisan::call('cache:clear');
      Artisan::call('config:clear');
      Artisan::call('route:clear');
      Artisan::call('view:clear');
      Toastr::success('Cache, route, view, config cleared successfully!');
      return back();
    }
}
