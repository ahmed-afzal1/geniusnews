<div class="row">
    <div class="col-lg-12 ">
      <nav>
        <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
          <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Upload Audio</a>
        </div>
      </nav>
      <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <div class="row mt-3">
                <div class="col-lg-12">
                    <div class="add-product-content">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="product-description">
                                    <div class="body-area">
                                        <div class="row">
                                            <div class="col-lg-2">
                                                <div class="left-area">
                                                    <h4 class="heading">{{ __('Audio') }} *</h4>
                                                </div>
                                            </div>
                                            <div class="col-lg-10">
                                            <input type="file" name="audio" id="audio1" value="157778789701.HAK-Hamari_Adhuri_Kahani.mp3">
                                                {{-- <audio src="{{asset('assets/images/audio/'.$data->audio)}}" controls id="myAudio" style="display: none;" class="mt-4"></audio> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    
    </div>
  </div>