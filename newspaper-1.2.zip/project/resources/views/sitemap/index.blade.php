<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>{{ route('sitemap.posts') }}</loc>
        <loc>{{ route('sitemap.categories') }}</loc>
        <loc>{{ route('sitemap.subcategories') }}</loc>
    </sitemap>   
</sitemapindex>